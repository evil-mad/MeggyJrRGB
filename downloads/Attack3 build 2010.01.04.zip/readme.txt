Attack v3 by Emo Mosley on 1-4-2010, based from:
  MeggyJr_Attack  -- Attack of the Cherry Tomatoes for Meggy Jr RGB
  Version 2.0 - 11/2008      http://www.evilmadscientist.com/
  Copyright (c) 2008 Chris Brookfield.  All right reserved.
 
Font code taken from:
  Bubbles from Outer Space - Meggy Jr version
  MeggyJr_Bubbles.pde v1.00
  Example file using the The Meggy Jr Simplified Library (MJSL) from the
  Meggy Jr RGB library for Arduino
  Font respectfully "borrowed" from the example file MeggyJr_ScrollText
     Thanks to Windell H. Oskay [http://www.evilmadscientist.com/]


New features in Version 3:
  - score keeping, displayed at the end of each game
    - 5 points per cherry tomato badguy
    - bonus points for extra tomatoes killed per one laser shot or bomb
  - player gets 2 spare ships before game over (3 lives)
  - number of spare ships displayed in bottom-right, indicated by green dots
  - player earns spare ships every 1000 points, each successive ship costs that much more
  - number of laser shots available now display as orange dots in upper-left
  - buzzing error sound when trying to use an empty weapon (laser or bomb)
  - extra points for pushing ahead courageously (1 X level pts per move forward)
  - the game can be paused by holding Right and pressing A; press A or B to unpause
  - current program version is displayed by pressing Up while paused

To Do:
  - 2-player?
  - power-ups?
  - new weapons?
  - boss after every 3 levels or so?
  - random tougher tomatoes?

