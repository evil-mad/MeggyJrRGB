/*
  Stalagfight - Fly through a cave filled with fear and firepower
  Version 1.0 - 09/01/2009
  Copyright (c) 2009 Wesley Crossman.  All right reserved.

    This library is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library.  If not, see <http://www.gnu.org/licenses/>.
  
*/

#ifndef SHARED_H
#define SHARED_H

#include <string.h>

typedef unsigned long ulong;
typedef unsigned int uint;

//shortened names of palette colors for use in arrays
enum ShortColors {
  D, R, O, Y, G, B, V, W, DR, DO, DY, DG, DA, DB, DV, FO,
  C0, C1, C2, C3, C4, C5, C6, C7, C8, C9};

//waits for the tone to complete
void Tone_Sleep(int tone, int msec) {
  Tone_Start(tone, msec);
  delay(msec);
}

//use to prevent key press from leaking from one keydown check to another
bool waitForRelease() {
  if (Meg.GetButtons()) {
    while (Meg.GetButtons()) {}
    return true;
  }
  return false;
}

//a faster, multicolored version of ClearSlate
void fillSlate(byte color) {
  memset(GameSlate, color, 8*8);
}

//save a temporary copy of the current MeggyJrSimple board
void saveSlate(byte *slate) {
  memcpy(slate, GameSlate, 8*8);
}

//restore the MeggyJrSimple board from a temporary copy
void restoreSlate(byte *slate) {
  memcpy(GameSlate, slate, 8*8);
}

//draw to invalid positions without crashing
bool safeDrawPx(byte xin, byte yin, byte color) {
  if (xin >= 0 && xin <= 7 && yin >= 0 && yin <= 7) {
    DrawPx(xin, yin, color);
    return true;
  }
  return false;
}

#endif

