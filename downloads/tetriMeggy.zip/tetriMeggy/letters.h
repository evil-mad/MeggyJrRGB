/*
  letters.h - Simple scrolling text
  Version 1.0 - 09/01/2009
  Copyright (c) 2009 Wesley Crossman.  All right reserved.

    This library is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this library.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef LETTERS_H
#define LETTERS_H

#include <string.h>
#include "Flash.h"

#undef BONUS_LETTERS
#define LOWERCASE_LETTERS
#define CUSTOM_SLOTS 0 //cannot be over 31

FLASH_ARRAY(byte, letterLen,
    2, 1, 3, 3, 3, 5, 3, 1, 2, //32-40, inclusive
    2, 3, 3, 1, 3, 1, 5, 3, 2, //41-49
    3, 3, 3, 3, 3, 3, 3, 3, 1, //50-58
    1, 3, 4, 3, 3, 3, 3, 3, 3, //59-67
    3, 3, 3, 4, 3, 3, 4, 4, 3, //68-76
    5, 4, 4, 4, 5, 4, 4, 3, 3, //77-85
    3, 5, 5, 5, 4, 2, 5, 2, 3, //86-94
    5, 2, 3, 3, 3, 3, 3, 2, 3, //95-103
    3, 1, 2, 3, 1, 5, 3, 3, 3, //104-112
    3, 2, 3, 3, 3, 3, 5, 3, 3, //113-121
    4, 3, 1, 3, 5 //122-126
);

#ifdef BONUS_LETTERS
const byte bonusArrowRightLength = 7;
FLASH_ARRAY(byte, bonusArrowRight,
    0,0,0,0,1,0,0,
    0,0,0,0,1,1,0,
    1,1,1,1,1,1,1,
    0,0,0,0,1,1,0,
    0,0,0,0,1,0,0
);

const byte bonusArrowLeftLength = 7;
FLASH_ARRAY(byte, bonusArrowLeft,
    0,0,1,0,0,0,0,
    0,1,1,0,0,0,0,
    1,1,1,1,1,1,1,
    0,1,1,0,0,0,0,
    0,0,1,0,0,0,0
);

const byte bonusHeartLength = 7;
FLASH_ARRAY(byte, bonusHeart,
    0,1,1,0,1,1,0,
    1,1,1,1,1,1,1,
    0,1,1,1,1,1,0,
    0,0,1,1,1,0,0,
    0,0,0,1,0,0,0
);

const byte bonusDiamondLength = 5;
FLASH_ARRAY(byte, bonusDiamond,
    0,0,1,0,0,
    0,1,1,1,0,
    1,1,1,1,1,
    0,1,1,1,0,
    0,0,1,0,0
);

const byte bonusSpadeLength = 5;
FLASH_ARRAY(byte, bonusSpade,
    0,0,1,0,0,
    0,1,1,1,0,
    1,1,1,1,1,
    1,1,1,1,1,
    0,0,1,0,0
);

const byte bonusClubsLength = 5;
FLASH_ARRAY(byte, bonusClubs,
    0,1,1,1,0,
    0,1,0,1,0,
    1,0,1,0,1,
    1,1,1,1,1,
    0,0,1,0,0
);

const byte bonusCircleLength = 5;
FLASH_ARRAY(byte, bonusCircle,
    0,1,1,1,0,
    1,0,0,0,1,
    1,0,0,0,1,
    1,0,0,0,1,
    0,1,1,1,0
);

const byte bonusSquareLength = 5;
FLASH_ARRAY(byte, bonusSquare,
    1,1,1,1,1,
    1,0,0,0,1,
    1,0,0,0,1,
    1,0,0,0,1,
    1,1,1,1,1
);

const byte bonusSmileLength = 5;
FLASH_ARRAY(byte, bonusSmile,
    0,0,0,0,0,
    0,1,0,1,0,
    0,0,0,0,0,
    1,0,0,0,1,
    0,1,1,1,0
);

const byte bonusNeutralFaceLength = 5;
FLASH_ARRAY(byte, bonusNeutralFace,
    0,0,0,0,0,
    0,1,0,1,0,
    0,0,0,0,0,
    0,1,1,1,0,
    0,0,0,0,0
);

const byte bonusFrownLength = 5;
FLASH_ARRAY(byte, bonusFrown,
    0,0,0,0,0,
    0,1,0,1,0,
    0,0,0,0,0,
    0,1,1,1,0,
    1,0,0,0,1
);

#endif

FLASH_TABLE(byte, block45to58, 3*5,
    { //hyphen 45
    0,0,0,
    0,0,0,
    1,1,1,
    0,0,0,
    0,0,0
    },
    { //period 46
    0,0,0,
    0,0,0,
    0,0,0,
    0,0,0,
    1,0,0
    },
    { //slash 47
    0,0,0,
    0,0,0,
    0,0,1,
    0,1,0,
    1,0,0
    },
    { //zero 48
    1,1,1,
    1,0,1,
    1,0,1,
    1,0,1,
    1,1,1
    },
    { //one 49
    0,1,0,
    1,1,0,
    0,1,0,
    0,1,0,
    0,1,0
    },
    { //two 50
    1,1,1,
    0,0,1,
    1,1,1,
    1,0,0,
    1,1,1
    },
    { //three 51
    1,1,1,
    0,0,1,
    0,1,1,
    0,0,1,
    1,1,1
    },
    { //four 52
    1,0,1,
    1,0,1,
    1,1,1,
    0,0,1,
    0,0,1
    },
    { //five 53
    1,1,1,
    1,0,0,
    1,1,1,
    0,0,1,
    1,1,1
    },
    { //six 54
    1,1,1,
    1,0,0,
    1,1,1,
    1,0,1,
    1,1,1
    },
    { //seven 55
    1,1,1,
    0,0,1,
    0,0,1,
    0,0,1,
    0,0,1
    },
    { //eight 56
    1,1,1,
    1,0,1,
    1,1,1,
    1,0,1,
    1,1,1
    },
    { //nine 57
    1,1,1,
    1,0,1,
    1,1,1,
    0,0,1,
    1,1,1
    },
    { //colon 58
    0,0,0,
    1,0,0,
    0,0,0,
    1,0,0,
    0,0,0
    }
);

FLASH_TABLE(byte, block60to96, 5*5,
    { //less-than 60
    0,0,1,0,0,
    0,1,0,0,0,
    1,0,0,0,0,
    0,1,0,0,0,
    0,0,1,0,0
    },
    { //equals 61
    0,0,0,0,0,
    1,1,1,1,0,
    0,0,0,0,0,
    1,1,1,1,0,
    0,0,0,0,0
    },
    { //greater-than 62
    1,0,0,0,0,
    0,1,0,0,0,
    0,0,1,0,0,
    0,1,0,0,0,
    1,0,0,0,0
    },
    { //question 63
    1,1,1,0,0,
    0,0,1,0,0,
    0,1,1,0,0,
    0,0,0,0,0,
    0,1,0,0,0
    },
    { //at symbol 64
    1,1,1,0,0,
    1,0,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0
    },
    { //A 65
    0,1,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    1,0,1,0,0
    },
    { //B 66
    1,1,0,0,0,
    1,0,1,0,0,
    1,1,0,0,0,
    1,0,1,0,0,
    1,1,0,0,0
    },
    { //C 67
    1,1,1,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,1,1,0,0
    },
    { //D 68
    1,1,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,0,0,0
    },
    { //E 69
    1,1,1,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    1,0,0,0,0,
    1,1,1,0,0
    },
    { //F 70
    1,1,1,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    1,0,0,0,0,
    1,0,0,0,0
    },
    { //G 71
    1,1,1,1,0,
    1,0,0,0,0,
    1,0,1,1,0,
    1,0,0,1,0,
    1,1,1,1,0
    },
    { //H 72
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0
    },
    { //I 73
    1,1,1,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    1,1,1,0,0
    },
    { //J 74
    0,1,1,1,0,
    0,0,1,0,0,
    0,0,1,0,0,
    1,0,1,0,0,
    0,1,0,0,0
    },
    { //K 75
    1,0,0,1,0,
    1,0,1,0,0,
    1,1,0,0,0,
    1,0,1,0,0,
    1,0,0,1,0
    },
    { //L 76
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,1,1,0,0
    },
    { //M 77
    1,1,0,1,1,
    1,0,1,0,1,
    1,0,1,0,1,
    1,0,1,0,1,
    1,0,1,0,1
    },
    { //N 78
    1,0,0,0,0,
    1,1,1,1,0,
    1,0,0,1,0,
    1,0,0,1,0,
    1,0,0,1,0
    },
    { //O 79
    1,1,1,1,0,
    1,0,0,1,0,
    1,0,0,1,0,
    1,0,0,1,0,
    1,1,1,1,0
    },
    { //P 80
    1,1,1,1,0,
    1,0,0,1,0,
    1,1,1,1,0,
    1,0,0,0,0,
    1,0,0,0,0
    },
    { //Q 81
    1,1,1,1,0,
    1,0,0,1,0,
    1,0,0,1,0,
    1,1,1,1,0,
    0,0,0,0,1
    },
    { //R 82
    1,1,1,1,0,
    1,0,0,1,0,
    1,1,1,1,0,
    1,0,1,0,0,
    1,0,0,1,0
    },
    { //S 83
    1,1,1,1,0,
    1,0,0,0,0,
    1,1,1,1,0,
    0,0,0,1,0,
    1,1,1,1,0
    },
    { //T 84
    1,1,1,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0
    },
    { //U 85
    1,0,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0
    },
    { //V 86
    1,0,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    0,1,0,0,0
    },
    { //W 87
    1,0,0,0,1,
    1,0,0,0,1,
    1,0,1,0,1,
    1,0,1,0,1,
    1,1,0,1,1
    },
    { //X 88
    1,0,0,0,1,
    0,1,0,1,0,
    0,0,1,0,0,
    0,1,0,1,0,
    1,0,0,0,1
    },
    { //Y 89
    1,0,0,0,1,
    0,1,0,1,0,
    0,0,1,0,0,
    0,0,1,0,0,
    0,0,1,0,0
    },
    { //Z 90
    1,1,1,1,0,
    0,0,1,0,0,
    0,1,0,0,0,
    1,0,0,0,0,
    1,1,1,1,0
    },
    { //opening square bracket 91
    1,1,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,1,0,0,0
    },
    { //backslash 92
    1,0,0,0,0,
    0,1,0,0,0,
    0,0,1,0,0,
    0,0,0,1,0,
    0,0,0,0,1
    },
    { //closing square bracket 93
    1,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    1,1,0,0,0
    },
    { //caret 94
    0,1,0,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //underscore 95
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1
    },
    { //backtick 96
    1,0,0,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    }
);

//32-44, 59, 97-126 (inclusive)
FLASH_TABLE(byte, masterRange, 5*7,
    { //space 32
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //exclamation 33
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //double-quote 34
    1,0,1,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //hash 35
    0,1,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //dollar sign 36
    0,1,0,0,0,
    1,1,1,0,0,
    1,1,0,0,0,
    0,1,1,0,0,
    1,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //percent 37
    1,0,0,0,1,
    0,0,0,1,0,
    0,0,1,0,0,
    0,1,0,0,0,
    1,0,0,0,1,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //ampersand (plus) 38
    0,0,0,0,0,
    0,1,0,0,0,
    1,1,1,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //single-quote 39
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //opening parenthesis 40
    0,1,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //closing parenthesis 41
    1,0,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //star 42
    0,0,0,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //plus 43
    0,0,0,0,0,
    0,1,0,0,0,
    1,1,1,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //comma 44
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0
    },

    //*** SYMBOLS AND NUMBERS GO HERE ***

    { //semicolon 59
    0,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0
    }

    //*** CAPITAL LETTERS AND SYMBOLS GO HERE ***

#ifdef LOWERCASE_LETTERS
    ,
    { //a 97
    0,0,0,0,0,
    0,0,0,0,0,
    0,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //b 98
    1,0,0,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //c 99
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //d 100
    0,0,1,0,0,
    0,0,1,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //e 101
    0,1,0,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    1,0,0,0,0,
    0,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //f 102
    0,0,0,0,0,
    1,1,0,0,0,
    1,0,0,0,0,
    1,1,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //g 103
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,1,0,0,
    1,1,1,0,0
    },
    { //h 104
    1,0,0,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //i 105
    1,0,0,0,0,
    0,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //j 106
    0,0,0,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    1,1,0,0,0
    },
    { //k 107
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,1,0,0,
    1,1,0,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //l 108
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //m 109
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,0,1,0,1,
    1,0,1,0,1,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //n 110
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //o 111
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //p 112
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    1,0,0,0,0,
    1,0,0,0,0
    },
    { //q 113
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,1,0,0,
    0,0,1,0,0
    },
    { //r 114
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //s (S) 115
    1,1,1,0,0,
    1,0,0,0,0,
    1,1,1,0,0,
    0,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //t 116
    0,1,0,0,0,
    1,1,1,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //u 117
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //v 118
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    0,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //w 119
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,1,0,1,
    1,0,1,0,1,
    0,1,0,1,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //x 120
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,1,0,0,
    0,1,0,0,0,
    1,0,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //y 121
    0,0,0,0,0,
    0,0,0,0,0,
    1,0,1,0,0,
    1,0,1,0,0,
    1,1,1,0,0,
    0,0,1,0,0,
    0,1,1,0,0
    },
    { //z 122
    0,0,0,0,0,
    1,1,1,1,0,
    0,0,1,0,0,
    0,1,0,0,0,
    1,1,1,1,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //opening brace 123
    0,1,1,0,0,
    0,1,0,0,0,
    1,1,0,0,0,
    0,1,0,0,0,
    0,1,1,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //vertical line 124
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0
    },
    { //closing brace 125
    1,1,0,0,0,
    0,1,0,0,0,
    0,1,1,0,0,
    0,1,0,0,0,
    1,1,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    },
    { //tilde 126
    0,0,0,0,0,
    1,0,1,1,0,
    0,1,0,0,1,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0
    }
#endif
);

_FLASH_ARRAY<byte> custom[CUSTOM_SLOTS];
byte customWidth[CUSTOM_SLOTS];
byte customHeight[CUSTOM_SLOTS];

//padding between letters
byte getPadding(char first, char second) {
  if (first == 't' && second == 't') return 0;
  else if ( (first == '\'' || first == '"') && (second == '\'' || second == '"') ) return 2;
  else return 1;
}




///////////////////////////////////////////////////////////////////////////
// PUBLIC USE FUNCTIONS                                                  //
///////////////////////////////////////////////////////////////////////////



//Usable for range of 1 to CUSTOM_SLOTS, inclusive
void setCustomLetter(char letter, _FLASH_ARRAY<byte> data, byte width, byte height) {
  if (letter >= 0 && letter < CUSTOM_SLOTS) {
    custom[letter-1] = data;
    customWidth[letter-1] = width;
    customHeight[letter-1] = height;
  }
}

class TextPosition {
public:
  const char *text;
  unsigned int stringLen;
  struct Data {
    unsigned int posChar;
    byte posInChar, currentChar, currentCharLen, currentTotalCharLen;
    byte currentCharArrayW, currentCharArrayH;
    _FLASH_ARRAY<byte> currentCharArray;
  } data, backup;
  TextPosition(const char *text);
  void decrement();
  void increment();
  TextPosition &operator--(int dummy) {decrement(); return *this;}
  TextPosition &operator++(int dummy) {increment(); return *this;}
  TextPosition &operator--() {decrement(); return *this;}
  TextPosition &operator++() {increment(); return *this;}
  TextPosition &operator-=(unsigned int v) {for (unsigned int a=0;a<v;++a) decrement(); return *this;}
  TextPosition &operator+=(unsigned int v) {for (unsigned int a=0;a<v;++a) increment(); return *this;}
  void save();
  void restore();
private:
  byte getCharLen() {
    if (data.currentChar >= 32) {
      return letterLen[data.currentChar-32];
    } else {
      return customWidth[data.currentChar-1];
    }
  }
  byte getTotalCharLen() {return data.currentCharLen + getPadding(data.currentChar,
        text[(data.posChar < stringLen-1) ? data.posChar+1 : 0]);}
  _FLASH_ARRAY<byte> getCharacterArray(byte &width, byte &height);
};

TextPosition::TextPosition(const char *text) {
  TextPosition::text = text;
  //we start one column behind the first letter to give it more time
  stringLen = strlen(text);
  data.posChar = stringLen-1;
  data.currentChar = text[data.posChar];
  data.currentCharLen = getCharLen();
  data.currentTotalCharLen = getTotalCharLen();
  data.posInChar = data.currentTotalCharLen-1;
  data.currentCharArray = getCharacterArray(data.currentCharArrayW, data.currentCharArrayH);
}

_FLASH_ARRAY<byte> TextPosition::getCharacterArray(byte &width, byte &height) {
  char c = data.currentChar;
  if (c >= 45 && c <= 58) {
    width = 3; height = 5;
    return block45to58[c-45];
  } else if (c >= 60 && c <= 96) {
    width = 5; height = 5;
    return block60to96[c-60];
  } else if (c >= 32 && c <= 44) {
    width = 5; height = 7;
    return masterRange[c-32];
#ifdef LOWERCASE_LETTERS
  } else if (c >= 97 && c <= 126) {
    width = 5; height = 7;
    return masterRange[c-83];
#endif
  } else if (c == 59) {
    width = 5; height = 7;
    return masterRange[13];
  } else if (c < CUSTOM_SLOTS) {
    width = customWidth[c-1]; height = customHeight[c-1];
    return custom[c-1];
  }
}

void TextPosition::save() {
  backup = data;
}

void TextPosition::restore() {
  data = backup;
}

void TextPosition::decrement() {
  if ( --data.posInChar == -1 ) {
    data.posChar = (data.posChar-1 == -1) ? stringLen-1 : (data.posChar-1);
    data.currentChar = text[data.posChar];
    data.currentCharLen = getCharLen();
    data.posInChar = data.currentTotalCharLen = getTotalCharLen();
    data.currentCharArray = getCharacterArray(data.currentCharArrayW, data.currentCharArrayH);
  }
}

void TextPosition::increment() {
  if ( ++data.posInChar == data.currentTotalCharLen ) {
    data.posInChar = 0;
    data.posChar = (data.posChar+1) % stringLen;
    data.currentChar = text[data.posChar];
    data.currentCharLen = getCharLen();
    data.currentTotalCharLen = getTotalCharLen();
    data.currentCharArray = getCharacterArray(data.currentCharArrayW, data.currentCharArrayH);
  }
}

void renderText(TextPosition &pos, byte color = White) {
  pos.save();
  for (byte x=0;x<8;++x) {
    if (pos.data.posInChar < pos.data.currentCharLen) {
      for (byte y=0;y<pos.data.currentCharArrayH;++y) {
        bool value = pos.data.currentCharArray[(y*pos.data.currentCharArrayW)+pos.data.posInChar];
        DrawPx(x, 7-(y+1), value ? color : Dark);
      }
    }
    ++pos;
  }
  pos.restore();
}

#endif

