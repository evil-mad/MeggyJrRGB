Sample source:

http://www.archive.org/details/JeremyZuckerman

