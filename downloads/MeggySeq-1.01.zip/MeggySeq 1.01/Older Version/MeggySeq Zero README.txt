
MeggySeq 0.0

This is an older version of MeggySeq, before I tacked on
loads of features. It's very basic, so it may be easier
to start with if you're interested in what's going
on with MeggySeq.

