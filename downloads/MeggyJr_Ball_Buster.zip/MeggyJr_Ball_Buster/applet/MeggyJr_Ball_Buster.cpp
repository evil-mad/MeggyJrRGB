/*
 MeggyJr_Ball_Buster.pde
    
 Version 1.5 - 12/15/2008
 Copyright (c) 2008 Mark White, MD.  All right reserved.
 http://www.codefun.com/
 mark@codefun.com
 
 This game might have some potential.  I thought I'd put it out there and get some feedback before I fleshed out
 the final details.

 Objective:
 Move the blue box to hit the red ball and try to make the red ball miss the yellow object.
 More importantly, don't let the yellow object hit the blue box.  It is a game of keep away.
 
 Characters:
 Mole = Blue Box
 Rat = Red Ball
 Slug = Yellow Object
 
 BackStory:
 You are an American secret agent that has infiltrated the KGB.  You are the Mole.  You work with a double agent, known as
 the Rat.  Every time you come in contact with the Rat you score points, but the Rat betrays you to your enemies as well.  You must
 try to prevent the Rat from having too much contact with your Soviet counterparts, especially your nemesis, the Slug.  The Slug is a KGB
 internal affairs investigator who knows he has a mole on his hands, and he suspects that you are in fact the mole,
 but he needs more evidence.  The Slug is relentless in his pursuit of the Mole, and so you must avoid contact with him at all costs.
 Good luck, and God bless America.
 
 Points:
 Game Start = 128
 Rat contact with Mole = +3
 Rat contact with head of Slug = -2
 Rat contact with tail of Slug = -1
 Mole contact with head of Slug = -10 and 5 seconds of sleep time poison
 Rat contact with tail of Slug = -5 and 3 seconds of sleep time poison
  
 Buttons:
 Button A - Currently does nothing but make an irritating sound
 Button B - Currently does nothing but make an irritating sound 
 Left Button - Move Mole left
 Right Button - Move Mole right
 Up Button - Move Mole up
 Down Button - Move Mole down
 Aux LEDs - Display current score

 This library is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this library.  If not, see <http://www.gnu.org/licenses/>.
 	  
*/

#include <MeggyJrSimple.h>

#include "WProgram.h"
void setup();
void loop();
void DrawGame();
void ButtonCheck();
void SlugUpdate();
void RatUpdate();
void RatHitSlug();
void DrawBox (byte ThisX, byte ThisY, byte ThisW, byte ThisH, byte ThisColor);
unsigned long TimeNow, HoldTime, SlugTime, RatTime, PoisonTime;
int RatWait, SlugWait, PoisonWait;

int MyScore, SRatHitMole, SMoleHitSlug1, SMoleHitSlug2, SRatHitSlug1, SRatHitSlug2;
int xRat, yRat;
int rx, ry;
byte xMole, yMole;
byte ThisPx;
byte BackColor, RatColor, RatWallColor, RatMoleColor, MoleColor;

boolean HitWall, HitRat, HitSlug, NoMove; 
byte HitBox;
byte xHit, yHit;

int xSlug, ySlug;
int xSlug2, ySlug2;
int sx, sy;
byte SlugPx1, SlugPx2;
byte SlugColor1, SlugColor2, SlugMoleColor, ThisSlug, SlugMultiple, SlugCt, SlugRt;

void setup() // Set initial values
{

  MeggyJrSimpleSetup();
 
  xRat = 3; yRat = 1;  rx = 1;  ry = 1;
  xMole = 0;  yMole = 6;
  xSlug = 4;  ySlug = 0; sx = -1; sy = 1; ThisSlug = 1; SlugCt = 1; SlugRt = 1;
  HitWall = false;  HitBox = 0;  HitRat = false; HitSlug = false; NoMove = true;

  PoisonWait = 2000;
  PoisonTime = 0;
  RatWait = 140;
  SlugWait = 100;
  SlugMultiple = 6;
  RatTime = millis();
  SlugTime = RatTime;

  EditColor(CustomColor0, 0, 0, 0); // background color
  EditColor(CustomColor1, 12, 0, 0);  // Rat color
  EditColor(CustomColor2, 0, 0, 15);  // Mole color
  EditColor(CustomColor3, 15, 1, 1);  // Rat hitting wall color
  EditColor(CustomColor4, 6, 0, 12);  // Rat hitting mole color
  EditColor(CustomColor5, 0, 0, 1);  // slug hitting mole color
  EditColor(CustomColor6, 7, 9, 0);  // slug color1
  EditColor(CustomColor7, 12, 5, 0);  // slug color2

  BackColor = CustomColor0;
  RatColor = CustomColor1;
  MoleColor = CustomColor2;
  RatWallColor = CustomColor3;
  RatMoleColor = CustomColor4;
  SlugMoleColor = CustomColor5;
  SlugColor1 = CustomColor6;
  SlugColor2 = CustomColor7;
  
  MyScore = 128;
  SRatHitMole = 3;
  SRatHitSlug1 = -2;
  SRatHitSlug2 = -1;  
  SMoleHitSlug1 = -10;
  SMoleHitSlug2 = -5;
  
  DrawGame();

}  // End setup()


void loop()  // Run main loop
{
  CheckButtonsPress();
  Tone_Update();
  TimeNow = millis();
  
  if (NoMove) {ButtonCheck();}
  if (((TimeNow - SlugTime) > SlugWait) && NoMove) {SlugUpdate();}
  if (((TimeNow - RatTime) > RatWait) && NoMove) {RatUpdate();} 

  if (PoisonTime > 0) { // Is the mole poisoned?
    MoleColor = SlugMoleColor;
    if ((TimeNow - PoisonTime) > PoisonWait) {PoisonTime = 0;}}
  else {MoleColor = CustomColor2;} // end poison
  
  NoMove = true;
  HitWall = false;
  HitRat = 0;
  DrawGame();
  
}  // End Main Loop

void DrawGame()
{
  // draw background
  DrawBox(0,0,8,8,BackColor);
  // draw Mole
  DrawBox(xMole,yMole,2,2,MoleColor);
  // draw Slug
  DrawPx(xSlug, ySlug, SlugColor1);
  if ((xSlug2 > -1) && (xSlug2<8) && (ySlug2 > -1) && (ySlug2 < 8)) {
  DrawPx(xSlug2, ySlug2, SlugColor2);}
  // draw Rat
  DrawPx(xRat, yRat, RatColor);
  
  SetAuxLEDs(MyScore);
  
  DisplaySlate();
  NoMove = true;
}// end DrawGame

void ButtonCheck()
{
  if (Button_A) { // Repel 
    Tone_Start(ToneC3,100); }// end repel
    
  if (Button_B) { // Disappear
    Tone_Start(ToneB3,100); } // end disappear
    
  if (Button_Up) { // Move Mole up
    if (yMole < 6){ // hit right wall?
      yMole++;
      NoMove = false; } } // end Mole up
 
  if (Button_Down) { // Move Mole down
    if (yMole > 0){
      yMole--;
      NoMove = false; } } // end mole down
     
  if (Button_Left) { // Move Mole left
    if (xMole > 0){ // hit left wall?
      xMole--;
      NoMove = false; } } // end Mole Left
     
  if (Button_Right) { // Move Mole right
    if (xMole < 6){ // hit right wall?
      xMole++;
      NoMove = false; } }// end mole right
}// end ButtonCheck

void SlugUpdate()
{
  SlugCt++;
  NoMove = false;
  SlugTime = TimeNow;
  
  ThisSlug += SlugRt;  // Orbit and move the slug
  if (ThisSlug > 8) {ThisSlug = 1;}
  if (ThisSlug < 1) {ThisSlug = 8;}
  if (SlugCt >= SlugMultiple){// Time to move slug's head? 
    SlugCt = 1;
    xSlug += sx;
    ySlug += sy;
    if (xSlug < 0){xSlug = 0;}
    if (xSlug > 7){xSlug = 7;}
    if (ySlug < 0){ySlug = 0;}
    if (ySlug > 7){ySlug = 7;}}
  switch (ThisSlug) {// Set Slug's tail
    case 1: xSlug2 = xSlug - 1; ySlug2 = ySlug; break;
    case 2: xSlug2 = xSlug - 1; ySlug2 = ySlug + 1; break;
    case 3: xSlug2 = xSlug; ySlug2 = ySlug + 1; break;
    case 4: xSlug2 = xSlug + 1; ySlug2 = ySlug + 1; break;
    case 5: xSlug2 = xSlug + 1; ySlug2 = ySlug; break;
    case 6: xSlug2 = xSlug + 1; ySlug2 = ySlug - 1; break;
    case 7: xSlug2 = xSlug; ySlug2 = ySlug - 1; break;
    case 8: xSlug2 = xSlug - 1; ySlug2 = ySlug - 1; break;}

  SlugPx1 = ReadPx(xSlug, ySlug);  // Did the slug hit the mole?
  if ((xSlug2 > -1) && (xSlug2<8) && (ySlug2 > -1) && (ySlug2 < 8)) {
    SlugPx2 = ReadPx(xSlug2, ySlug2);}
  else {SlugPx2 = BackColor;}
 
  if (SlugPx1 == CustomColor2){ // How did the slug hit the Mole?
    Tone_Update();
    Tone_Start(3000, 150);
    sx = -sx;
    SlugRt = -SlugRt;
    MyScore += SMoleHitSlug1;
    PoisonTime = TimeNow;
    PoisonWait = 5000;}
  else {
    if (SlugPx2 == CustomColor2){
      Tone_Update();
      Tone_Start(4000, 120);
      sy = -sy;
      SlugRt = -SlugRt;
      MyScore += SMoleHitSlug2;
      PoisonTime = TimeNow;
      PoisonWait = 3000;}}// end slug hit mole
  
// Figure out which way the slug is going, and which way it needs to go
  if (sx>0) { //going right
    if (xSlug > 6){ // Hit right wall?
      sx = -1;} // end hit right wall   
    if (sy > 0) {  // going up and right 
      if (ySlug > 6) { // Hit top wall?
        sy = -1;} // end hit top wall
    }// end going up and right
    else {  // going down and right
      if (ySlug < 1) { // Hit bottom wall?
        sy = 1;} // end hit bottom wall
    } // end going down and right
  } // end going right
  else {  // going left
    if (xSlug < 1) { // hit left wall?
      sx = 1;}  // end hit left wall
    if (sy > 0) {  // going up and left
      if (ySlug > 6){ // Hit top wall?
        sy = -1;}// end hit top wall
    } // end going up and left
    else {  // going down and left
      if (ySlug < 1){ // hit left wall?
        sy = 1;} // end hit left wall
    } // end going down and left
  } // end going left
  RatHitSlug(); // Did rat hit slug?
} // end SlugUpdate

void RatUpdate()
{
  NoMove = false;
  RatTime = TimeNow;
  xRat += rx;
  yRat += ry;
  if (xRat < 0){xRat = 0;}
  if (xRat > 7){xRat = 7;}
  if (yRat < 0){yRat = 0;}
  if (yRat > 7){yRat = 7;}
  ThisPx = ReadPx(xRat, yRat);
  RatColor = CustomColor1;
  HitWall = false;
  
  HitBox = 0; // did the Rat hit the unPoisoned Mole? Where?
  if (ThisPx == CustomColor2){
    HitBox = 1;
    MyScore += SRatHitMole;
    RatColor = RatMoleColor;
    Tone_Start(10000,40);
    xHit = (xRat - xMole) * 2;
    HitBox += xHit;
    yHit = (yRat - yMole) * 4;
    HitBox += yHit;
  } // end hit box

// Figure out which way the Rat is going, and which way it needs to go
  if (rx>0) { //going right
    if (xRat > 6){ // Hit right wall?
      Tone_Start(11000,30);
      RatColor = CustomColor3;
      rx = -1;} // end hit right wall   
    if (ry > 0) {  // going up and right 
      if (yRat > 6){ // Hit top wall?
        Tone_Start(14000,30);
        RatColor = CustomColor3;
        ry = -1;} // end hit top wall
      switch (HitBox){ // bounce off box
        case 1: rx = -rx; ry = -ry; break;
        case 3: ry = -ry; break;
        case 5: rx = -rx; break;} // end bounce off box
    }// end going up and right
    else {  // going down and right
      if (yRat < 1){ // Hit bottom wall?
        Tone_Start(12000,30);
        RatColor = CustomColor3;
        ry = 1;} // end hit bottom wall
      switch (HitBox){ // bounce off box
        case 1: rx = -rx; break;
        case 5: rx = -rx; ry = -ry; break;
        case 7: ry = -ry; break;} // end bounce off box
    } // end going down and right
  } // end going right
  else {  // going left
    if (xRat < 1){ // hit left wall?
      Tone_Start(13000,30);
      RatColor = CustomColor3;
      rx = 1;}  // end hit left wall
    if (ry > 0) {  // going up and left
      if (yRat > 6){ // Hit top wall?
        Tone_Start(8000,40);
        RatColor = CustomColor3;
        ry = -1;}// end hit top wall
      switch (HitBox){ // bounce off box
        case 1: ry = -ry; break;
        case 3: rx = -rx; ry = -ry; break;
        case 7: rx = -rx; break;} // end bounce off box
    } // end going up and left
    else {  // going down and left
      if (yRat < 1){ // hit left wall?
        Tone_Start(8000,40);
        RatColor = CustomColor3;
        ry = 1;} // end hit left wall
      switch (HitBox){ // bounce off box
        case 3: rx = -rx; break;
        case 5: ry = -ry; break;
        case 7: rx = -rx; ry = -ry; break;} // end bounce off box
    } // end going down and left
  } // end going left
  RatHitSlug(); // Did rat hit slug?
  if (xRat < 0){xRat = 0;}
  if (xRat > 7){xRat = 7;}
  if (yRat < 0){yRat = 0;}
  if (yRat > 7){yRat = 7;}
}// end RatUpdate

void RatHitSlug()
{
  Tone_Update();
  if ((xRat == xSlug2) && (yRat == ySlug2)) {
    Tone_Start(6000,60);
    MyScore += SRatHitSlug2;
    xSlug += rx;
    ySlug += ry;
    rx = -rx;
    ry = -ry;}
  if ((xRat == xSlug) && (yRat == ySlug)) {
    Tone_Start(5000,70);
    MyScore += SRatHitSlug1;
    if ((rx == -sx) && (ry == -sy)) {
      xSlug -= rx;
      ySlug -= ry;
      sx = -sx;
      ry = -ry;}
    else {
      xSlug += rx;
      ySlug += ry;
      rx = -rx;
      ry = -ry;}}
  if (xSlug < 0){xSlug = 0;}
  if (xSlug > 7){xSlug = 7;}
  if (ySlug < 0){ySlug = 0;}
  if (ySlug > 7){ySlug = 7;}
}// end RatHitSlug

// Draw a box of pixels
void DrawBox (byte ThisX, byte ThisY, byte ThisW, byte ThisH, byte ThisColor)
{
  byte i, j;
  for (i = ThisX; i < (ThisX + ThisW); i++){   
    for (j = ThisY; j < (ThisY + ThisH); j++){
      DrawPx(i,j,ThisColor);}}
}// end DrawBox

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

