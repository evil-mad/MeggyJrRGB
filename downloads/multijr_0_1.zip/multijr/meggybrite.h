//meggybrite.h
//define the meggybrite namespace

namespace meggybrite
{
  void sub_setup(void);
  void sub_loop(void);
  void splash(void);
}

