//froggyjr.h
//define the froggyjr namespace
//lets people play froggyjr

namespace froggyjr
{
  void sub_setup(void);//set up the game
  void sub_loop(void); //play a frame of the game
  void splash(void);   //demo the game for the menu
}

