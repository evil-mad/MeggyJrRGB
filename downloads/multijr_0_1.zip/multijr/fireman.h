//fireman.h
//define the fireman namespace
//in order to play the fireman game

namespace fireman
{
  void sub_setup(void); //initialize the game
  void sub_loop(void);  //continue the game
  void splash(void);    //represent the game in the menu
}

