//meggysays.h
//define the meggysays namespace

namespace meggysays
{
  void sub_setup(void);
  void sub_loop(void);
  void splash(void);
}

