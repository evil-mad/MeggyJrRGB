/*
 MeggyJr_RGBMix.pde
    
 This program allows you to mix your own RGB colors on a Meggy Jr.
 It loads the 16 standard MeggyJr colors and allows you to edit their RGB values to create custom colors.
    
 Version 1.2 - 12/02/2008
 Copyright (c) 2008 Mark White, MD.  All right reserved.
 http://www.codefun.com/

 The display is divided into five parts:
 
 Top left - Shows the current intensity of the pure Red, Green and Blue components.
 Top Right - Shows the binary value of Red, Green and Blue.
 Top Center - Shows the current selection of Red, Green and Blue, or all three.
 Bottom - Shows the current mix color based on the RGB values.
 Aux LEDs - Indicates the current color's original index in ColorTable[] as a binary value.
 
 Button A - Increases by 1 the value of the selected RGB component or components.
 Button B - Decreases by 1 the value of the selected RGB component or components.
 Left Button - Saves the current color and loads previous color.
 Right Button - Saves the current color and loads next color.
 Up Button - Shifts RGB component selection upward.
 Down Button - Shifts RGB component selection downward.

 This library is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this library.  If not, see <http://www.gnu.org/licenses/>.
 	  
*/

#include <MeggyJrSimple.h>    // Required code, line 1 of 2.

#include "WProgram.h"
void setup();
void loop();
void DrawBox (byte ThisX, byte ThisY, byte ThisW, byte ThisH, byte ThisColor);
byte pause;
byte Holdrgb[16][3];
byte Thisrgb, ThisHold, OldHold;
byte Nowrgb[3];

 
void setup()                    // run once, when the sketch starts
{

  MeggyJrSimpleSetup();      // Required code, line 2 of 2.
 
  pause = 1;
  Thisrgb = 0, ThisHold = 7;
  
  byte i;
  
  i=0;
  while (i<16)
  {
    Holdrgb[i][0]=ColorTable[i][0], Holdrgb[i][1]=ColorTable[i][1], Holdrgb[i][2]=ColorTable[i][2];
    i++;
  }
  Nowrgb[0]=ColorTable[ThisHold][0], Nowrgb[1]=ColorTable[ThisHold][1], Nowrgb[2]=ColorTable[ThisHold][2];

}  // End setup()


void loop()                     // run over and over again
{
 
  byte i, j;

  CheckButtonsPress();
  Tone_Update();
    
    if (Button_A) //"A" button            // Increase RGB by 1
    { 
      if (Thisrgb == 3)
      {
        if (Nowrgb[0] < 15) Nowrgb[0]++;
        if (Nowrgb[1] < 15) Nowrgb[1]++;
        if (Nowrgb[2] < 15) Nowrgb[2]++;
        i = ((Nowrgb[0] + Nowrgb[1] + Nowrgb[2])/3); 
      }
      else
      {
        if (Nowrgb[Thisrgb] < 15) Nowrgb[Thisrgb]++;
        i = Nowrgb[Thisrgb];
      }
     Tone_Start((16 - i)*2000,100);
     pause = 1;    
    }
    
    if (Button_B) //"B" button            // Decrease RGB by 1
    { 
      if (Thisrgb == 3)
      {
        if (Nowrgb[0] > 0) Nowrgb[0]--;
        if (Nowrgb[1] > 0) Nowrgb[1]--;
        if (Nowrgb[2] > 0) Nowrgb[2]--;
        i = ((Nowrgb[0] + Nowrgb[1] + Nowrgb[2])/3); 
      }
      else
      {
        if (Nowrgb[Thisrgb] > 0) Nowrgb[Thisrgb]--;
        i = Nowrgb[Thisrgb];
      }
      Tone_Start((16 - i)*2000,100);
      pause = 1;    
    }
    
    if (Button_Up)      // up button: Change color selection upward
     { 
       if (Thisrgb <= 0) {Thisrgb = 3;} else {Thisrgb--;}
       Tone_Start((4 - Thisrgb)*6000,200);
       pause = 1; 
     }

    if (Button_Down)    // down button: Change color selection downward
     { 
       if (Thisrgb >= 3) {Thisrgb = 0;} else {Thisrgb++;}
       Tone_Start((4 - Thisrgb)*6000,200);
       pause = 1; 
     }
     
    if (Button_Left)    // left button: Move left through saved colors
     { 
       OldHold = ThisHold;
       if (ThisHold <= 0) {ThisHold = 15;} else {ThisHold--;} 
       Holdrgb[OldHold][0] = Nowrgb[0]; Holdrgb[OldHold][1] = Nowrgb[1]; Holdrgb[OldHold][2] = Nowrgb[2];
       Nowrgb[0] = Holdrgb[ThisHold][0]; Nowrgb[1] = Holdrgb[ThisHold][1]; Nowrgb[2] = Holdrgb[ThisHold][2];
       Tone_Start((16 - ThisHold)*1750,250);
       pause = 1; 
     }
     
    if (Button_Right)   // right button: Move right through saved colors
     { 
       OldHold = ThisHold;
       if (ThisHold >= 15) {ThisHold = 0;} else {ThisHold++;} 
       Holdrgb[OldHold][0] = Nowrgb[0]; Holdrgb[OldHold][1] = Nowrgb[1]; Holdrgb[OldHold][2] = Nowrgb[2];
       Nowrgb[0] = Holdrgb[ThisHold][0]; Nowrgb[1] = Holdrgb[ThisHold][1]; Nowrgb[2] = Holdrgb[ThisHold][2];
       Tone_Start((16 - ThisHold)*1750,250);
       pause = 1; 
     }

// Draw the Screen

  if(pause == 1)  //  If a button is pushed then redraw the entire screen
  {
    EditColor (CustomColor0, Nowrgb[0], Nowrgb[1], Nowrgb[2]);
    EditColor (CustomColor1, Nowrgb[0], 0, 0);
    EditColor (CustomColor2, 0, Nowrgb[1], 0);
    EditColor (CustomColor3, 0, 0, Nowrgb[2]);
  
  //  Draw current color mix onto lower 5 lines
    DrawBox (0, 0, 8, 4, CustomColor0);
    
  //  Draw a line at top left with the current intensity of each r, g & b
    DrawBox (0, 7, 3, 1, CustomColor1);
    DrawBox (0, 6, 3, 1, CustomColor2);
    DrawBox (0, 5, 3, 1, CustomColor3);
  
  //  Show which color is currently selected
    if (Thisrgb == 0 || Thisrgb == 3) {DrawPx(3,7,FullOn);} else {DrawPx(3,7,Dark);}
    if (Thisrgb == 1 || Thisrgb == 3) {DrawPx(3,6,FullOn);} else {DrawPx(3,6,Dark);}
    if (Thisrgb == 2 || Thisrgb == 3) {DrawPx(3,5,FullOn);} else {DrawPx(3,5,Dark);}
  
  //  Show each RGB as binary value
    j=Nowrgb[0];
    if ((j & 8)>0) {DrawPx(4,7,Red);} else {DrawPx(4,7,Dark);}
    if ((j & 4)>0) {DrawPx(5,7,Red);} else {DrawPx(5,7,Dark);}
    if ((j & 2)>0) {DrawPx(6,7,Red);} else {DrawPx(6,7,Dark);}
    if ((j & 1)>0) {DrawPx(7,7,Red);} else {DrawPx(7,7,Dark);}
    j=Nowrgb[1];
    if ((j & 8)>0) {DrawPx(4,6,Green);} else {DrawPx(4,6,Dark);}
    if ((j & 4)>0) {DrawPx(5,6,Green);} else {DrawPx(5,6,Dark);}
    if ((j & 2)>0) {DrawPx(6,6,Green);} else {DrawPx(6,6,Dark);}
    if ((j & 1)>0) {DrawPx(7,6,Green);} else {DrawPx(7,6,Dark);}
    j=Nowrgb[2];
    if ((j & 8)>0) {DrawPx(4,5,Blue);} else {DrawPx(4,5,Dark);}
    if ((j & 4)>0) {DrawPx(5,5,Blue);} else {DrawPx(5,5,Dark);}
    if ((j & 2)>0) {DrawPx(6,5,Blue);} else {DrawPx(6,5,Dark);}
    if ((j & 1)>0) {DrawPx(7,5,Blue);} else {DrawPx(7,5,Dark);}
 
    SetAuxLEDs (ThisHold);
    DisplaySlate();
    pause = 0;  //  Stop drawing until a button is pushed
  }
}

// Draw a box of pixels
void DrawBox (byte ThisX, byte ThisY, byte ThisW, byte ThisH, byte ThisColor)
{
  byte i, iW, j, jH;
  i = ThisX;
  iW = (i + ThisW);
     
   while (i < iW){
      j = ThisY;
      jH = (j + ThisH);
        while ( j < jH){
          DrawPx(i,j,ThisColor);
          j++;
        }
   i++;
   }
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

